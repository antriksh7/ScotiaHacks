
document.addEventListener('DOMContentLoaded', () => {
    const trends = [
        { region: { en: 'Ontario', fr: 'Ontario', es: 'Ontario' }, fraudType: { en: 'Parking Ticket Payment Fraud', fr: 'Fraude de paiement de ticket de stationnement', es: 'Fraude de pago de boleto de estacionamiento' }, reports: 12000, url: 'parking-ticket-payment-fraud' },
        { region: { en: 'Brazil', fr: 'Brésil', es: 'Brasil' }, fraudType: { en: 'Interac Email Fraud', fr: 'Fraude par courriel Interac', es: 'Fraude por correo electrónico de Interac' }, reports: 95000, url: 'interac-email-fraud' },
        { region: { en: 'Mexico', fr: 'Mexique', es: 'México' }, fraudType: { en: 'Investment Fraud', fr: 'Fraude à l\'investissement', es: 'Fraude de inversión' }, reports: 8500, url: 'investment-fraud' },
        { region: { en: 'Nova Scotia', fr: 'Nouvelle-Écosse', es: 'Nueva Escocia' }, fraudType: { en: 'Lottery Scams', fr: 'Arnaques à la loterie', es: 'Estafas de lotería' }, reports: 43000, url: 'lottery-scams' },
        { region: { en: 'New York', fr: 'New York', es: 'Nueva York' }, fraudType: { en: 'PayPal Email Scam', fr: 'Vol d\'identité', es: 'Robo de identidad' }, reports: 78000, url: 'identity-theft' },
        { region: { en: 'Durham', fr: 'Durham', es: 'Durham' }, fraudType: { en: 'Banking Scam', fr: 'Arnaque bancaire', es: 'Estafa bancaria' }, reports: 66000, url: 'banking-scam' },
        { region: { en: 'Europe', fr: 'Europe', es: 'Europa' }, fraudType: { en: 'Online Shopping Scam', fr: 'Arnaque de shopping en ligne', es: 'Estafa de compras en línea' }, reports: 21000, url: 'online-shopping-scam' },
        { region: { en: 'North America', fr: 'Amérique du Nord', es: 'América del Norte' }, fraudType: { en: 'Phishing Scam', fr: 'Arnaque par hameçonnage', es: 'Estafa de phishing' }, reports: 32000, url: 'phishing-scam' },
        { region: { en: 'Asia', fr: 'Asie', es: 'Asia' }, fraudType: { en: 'Pyramid Scheme', fr: 'Système pyramidal', es: 'Esquema piramidal' }, reports: 15000, url: 'pyramid-scheme' }
    ];

    trends.sort((a, b) => b.reports - a.reports);

    const trendsContainer = document.getElementById('trending-frauds');
    const showMoreButton = document.getElementById('show-more');
    const showLessButton = document.getElementById('show-less');
    const initialVisibleCount = 3;
    let visibleCount = initialVisibleCount;

    let currentLanguage = 'en';

    function loadTrends() {
        trendsContainer.innerHTML = ''; 
        trends.slice(0, visibleCount).forEach(trend => {
            const trendElement = document.createElement('div');
            trendElement.classList.add('trend-item');

            const formattedReports = (trend.reports >= 1000) ? `${(trend.reports / 1000).toFixed(1)}K` : trend.reports;

            trendElement.innerHTML = `
                <div class="trend-info">
                    <a href="/fraud/${trend.url}">${trend.fraudType[currentLanguage]}</a>
                    <span>${trend.region[currentLanguage]} - ${formattedReports} reports</span>
                </div>
            `;

            trendsContainer.appendChild(trendElement);
        });

        if (visibleCount >= trends.length) {
            showMoreButton.style.display = 'none'; 
            showLessButton.style.display = 'block'; 
        } else {
            showMoreButton.style.display = 'block'; 
            showLessButton.style.display = 'none'; 
        }
    }

    function setLanguage(language) {
        currentLanguage = language;
        document.querySelectorAll('[data-en]').forEach(el => {
            el.textContent = el.getAttribute(`data-${language}`);
        });
        loadTrends();
    }

    document.getElementById('en-btn').addEventListener('click', () => setLanguage('en'));
    document.getElementById('fr-btn').addEventListener('click', () => setLanguage('fr'));
    document.getElementById('es-btn').addEventListener('click', () => setLanguage('es'));

    loadTrends();

    showMoreButton.addEventListener('click', (e) => {
        e.preventDefault();
        visibleCount = trends.length; 
        trendsContainer.style.maxHeight = '400px'; 
        loadTrends();
    });

    showLessButton.addEventListener('click', (e) => {
        e.preventDefault();
        visibleCount = initialVisibleCount; 
        trendsContainer.style.maxHeight = '200px'; 
        loadTrends();
    });
});
